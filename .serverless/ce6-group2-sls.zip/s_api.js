
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'joannewce6',
  applicationName: 'ce6-group2-sls',
  appUid: 'TBVTY5cW3pSvXxr6hw',
  orgUid: '8b82d59d-393a-42e6-8148-668303aceb9d',
  deploymentUid: 'bae2dc2b-daf7-4552-a8f0-45b8f2f3ec91',
  serviceName: 'ce6-group2-sls',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'ce6-group2-sls-dev-api', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}